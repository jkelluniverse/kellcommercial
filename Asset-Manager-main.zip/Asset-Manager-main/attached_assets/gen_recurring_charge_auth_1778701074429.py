"""
Recurring Charge Authorization Generator — NCH
================================================
Fills TEMPLATE_recurring_charge_auth.docx with tenant name,
property address, and rent amount. All payment method fields
(ACH account numbers, card details) are left blank for handwriting
at the time of signing.

FORM FIELDS:
  tenant_name       str    full legal name of tenant/purchaser
  property_address  str    full property address
  rent_amount       str    monthly rent e.g. "1,250.00"
"""

import os, shutil, subprocess, tempfile
from docx import Document


def _replace_in_para(para, replacements):
    full_text = para.text
    if not any(k in full_text for k in replacements):
        return
    runs = para.runs
    if not runs:
        return
    combined = ''.join(r.text for r in runs)
    new_text = combined
    for k, v in replacements.items():
        new_text = new_text.replace(k, v)
    if new_text == combined:
        return
    runs[0].text = new_text
    for r in runs[1:]:
        r.text = ''


def _fill_doc(doc, replacements):
    for para in doc.paragraphs:
        _replace_in_para(para, replacements)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    _replace_in_para(para, replacements)
    for section in doc.sections:
        for para in section.header.paragraphs:
            _replace_in_para(para, replacements)
        for para in section.footer.paragraphs:
            _replace_in_para(para, replacements)


def _docx_to_pdf(docx_path, output_path):
    out_dir = os.path.dirname(output_path)
    subprocess.run(
        ['soffice', '--headless', '--convert-to', 'pdf',
         '--outdir', out_dir, docx_path],
        capture_output=True, text=True, timeout=60
    )
    base = os.path.splitext(os.path.basename(docx_path))[0]
    generated = os.path.join(out_dir, base + '.pdf')
    if os.path.exists(generated) and generated != output_path:
        os.rename(generated, output_path)
    if not os.path.exists(output_path):
        raise RuntimeError('PDF conversion failed')
    return output_path


def generate_recurring_charge_auth(data, output_path=None):
    """
    Generate the Recurring Charge Authorization form as a PDF.
    Pre-fills tenant name, property address, and rent amount.
    All payment method fields remain blank for handwriting at signing.
    """
    _here = os.path.dirname(os.path.abspath(__file__))
    for _td in [os.path.join(_here, '..', 'doc_templates'),
                os.path.join(_here, 'doc_templates'), _here]:
        template_path = os.path.join(os.path.abspath(_td),
                                     'TEMPLATE_recurring_charge_auth.docx')
        if os.path.exists(template_path):
            break

    tenant      = data['tenant_name']
    prop_addr   = data['property_address']
    rent_amount = data.get('rent_amount', '')

    # Format rent amount — strip $ and commas then reformat
    if rent_amount:
        clean = str(rent_amount).replace('$', '').replace(',', '').strip()
        try:
            rent_display = f'{float(clean):,.2f}'
        except ValueError:
            rent_display = clean
    else:
        rent_display = '____________'

    replacements = {
        '[[TENANT_NAME]]':      tenant,
        '[[PROPERTY_ADDRESS]]': prop_addr,
        '[[RENT_AMOUNT]]':      rent_display,
    }

    if output_path is None:
        safe = tenant.replace(' ', '_').replace('/', '_')
        output_path = f'/tmp/RecurringChargeAuth_{safe}.pdf'

    with tempfile.TemporaryDirectory() as tmpdir:
        working = os.path.join(tmpdir, 'rca_filled.docx')
        shutil.copy2(template_path, working)
        doc = Document(working)
        _fill_doc(doc, replacements)
        doc.save(working)
        _docx_to_pdf(working, output_path)

    return output_path


if __name__ == '__main__':
    import os
    os.makedirs('/home/claude/doc_templates', exist_ok=True)
    shutil.copy('/home/claude/TEMPLATE_recurring_charge_auth.docx',
                '/home/claude/doc_templates/TEMPLATE_recurring_charge_auth.docx')

    out = generate_recurring_charge_auth({
        'tenant_name':      'Sherard Anton Smith',
        'property_address': '1708 5th St SE, Canton, Ohio 44707',
        'rent_amount':      '1200.00',
    }, '/home/claude/RecurringChargeAuth_Test.pdf')
    print(f'Generated: {out}')
