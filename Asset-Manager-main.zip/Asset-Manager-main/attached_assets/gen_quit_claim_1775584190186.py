"""
Quit Claim Deed Generator
==========================
Fills [[PLACEHOLDERS]] in the original Word template and converts to PDF
using LibreOffice. Output is pixel-perfect match to the original document.

Template file: backend/doc_templates/TEMPLATE_quit_claim.docx
LibreOffice must be installed on the server.

IMPORTANT NAMING NOTE:
  In the original template, [[BUYER_NAME]] refers to the GRANTOR
  (the person giving up the property). In the app form we call this
  "grantor_name" to avoid confusion. This generator maps grantor_name
  back to [[BUYER_NAME]] for the template.

FORM FIELDS (what the app collects):
  grantor_name          str    person/entity transferring the property
  grantor_signatory     str    person who physically signs
                               (same as grantor_name if individual)
  grantee_name          str    person receiving the property
  property_address      str    full address e.g. "1117 Arlington Ave SW, Canton OH 44706"
  parcel_no             str    Stark County parcel ID number
  legal_description     str    full legal description verbatim
  prior_deed_instrument str    optional recorder instrument number
  execution_year        str    year of execution e.g. "2026"
  notary_day            str    day of notarization — left blank, filled at signing
  notary_month          str    month of notarization — left blank, filled at signing

STATIC (never changes — hardcoded in template):
  consideration = ONE DOLLAR ($1.00)
  All subject-to clauses
  TO HAVE AND TO HOLD clause
  Dower release language
  STATE OF OHIO / COUNTY OF STARK notary blocks
  "This Instrument was prepared by: Grantee"
"""

import os
import re
import shutil
import subprocess
import tempfile
from docx import Document


# ── Core fill helpers ──────────────────────────────────────────────────────────
def _replace_in_para(para, replacements):
    """Replace placeholders in a paragraph handling split runs."""
    full_text = para.text
    if not any(k in full_text for k in replacements):
        return
    runs = para.runs
    if not runs:
        return
    combined = ''.join(r.text for r in runs)
    new_text = combined
    for k, v in replacements.items():
        new_text = new_text.replace(k, v)
    if new_text == combined:
        return
    runs[0].text = new_text
    for r in runs[1:]:
        r.text = ''


def _fill_doc(doc, replacements):
    """Fill all placeholders throughout the entire document."""
    for para in doc.paragraphs:
        _replace_in_para(para, replacements)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    _replace_in_para(para, replacements)
    for section in doc.sections:
        for para in section.header.paragraphs:
            _replace_in_para(para, replacements)
        for para in section.footer.paragraphs:
            _replace_in_para(para, replacements)


def _docx_to_pdf(docx_path, output_path):
    """Convert a docx file to PDF using LibreOffice."""
    out_dir = os.path.dirname(output_path)
    result = subprocess.run(
        ['soffice', '--headless', '--convert-to', 'pdf',
         '--outdir', out_dir, docx_path],
        capture_output=True, text=True, timeout=60
    )
    base = os.path.splitext(os.path.basename(docx_path))[0]
    generated = os.path.join(out_dir, base + '.pdf')
    if os.path.exists(generated) and generated != output_path:
        os.rename(generated, output_path)
    if not os.path.exists(output_path):
        raise RuntimeError(f'PDF conversion failed: {result.stderr}')
    return output_path


# ── Main generator ─────────────────────────────────────────────────────────────
def generate_quit_claim_deed(data, output_path=None):
    """
    Fill the quit claim deed template with data and return path to generated PDF.
    data: dict with fields listed in module docstring.
    output_path: where to save the PDF (defaults to /tmp).
    """
    template_path = os.path.join(
        os.path.dirname(__file__), '..', 'doc_templates',
        'TEMPLATE_quit_claim.docx'
    )
    template_path = os.path.abspath(template_path)

    grantor   = data['grantor_name']
    signatory = data.get('grantor_signatory', grantor)
    grantee   = data['grantee_name']
    addr      = data['property_address']
    parcel    = data['parcel_no']
    legal     = data['legal_description']
    prior     = data.get('prior_deed_instrument', '')
    exec_year = data.get('execution_year', '2026')
    n_day     = data.get('notary_day', '______')
    n_month   = data.get('notary_month', '____________________')

    # [[BUYER_NAME]] in the template = grantor in the app
    # It appears multiple times: opening clause, dower release, signature, notary
    replacements = {
        '[[BUYER_NAME]]':        grantor,
        '[[GRANTEE_NAME]]':      grantee,
        '[[LEGAL_DESCRIPTION]]': legal,
        '[[PARCEL_NO]]':         parcel,
        '[[PROPERTY_ADDRESS]]':  addr,
    }

    # Handle prior deed instrument if provided
    if prior:
        replacements['Prior deed Instrument Number: ___________________________'] = \
            f'Prior deed Instrument Number: {prior}'

    # Handle notary date fields if provided
    # The template has: "this ______ day of ____________________, 2026"
    if n_day != '______' or n_month != '____________________':
        replacements['this ______ day of ____________________, 2026'] = \
            f'this {n_day} day of {n_month}, {exec_year}'

    # Handle execution year if different from 2026
    if exec_year != '2026':
        replacements['two thousand and twenty six'] = \
            f'two thousand and twenty {exec_year[-2:]}'
        replacements[', 2026.'] = f', {exec_year}.'
        replacements[', 2026,'] = f', {exec_year},'

    if output_path is None:
        safe = grantee.replace(' ', '_').replace('/', '_')
        output_path = os.path.join(tempfile.gettempdir(), f'QuitClaimDeed_{safe}.pdf')

    with tempfile.TemporaryDirectory() as tmpdir:
        working_docx = os.path.join(tmpdir, 'quit_claim_filled.docx')
        shutil.copy2(template_path, working_docx)

        doc = Document(working_docx)
        _fill_doc(doc, replacements)
        doc.save(working_docx)

        _docx_to_pdf(working_docx, output_path)

    return output_path


# ── Test ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    sample = {
        'grantor_name':          'John A. Smith',
        'grantor_signatory':     'John A. Smith',
        'grantee_name':          'Nice City Homes LLC',
        'property_address':      '1117 Arlington Ave SW, Canton OH 44706',
        'parcel_no':             '10-12345-000',
        'legal_description':     'Lot 14 of Plat No. 5, Reedsburg Heights Addition '
                                 'to the City of Canton, Stark County, Ohio, as '
                                 'recorded in Plat Book 12, Page 47.',
        'prior_deed_instrument': '2024-00012345',
        'execution_year':        '2026',
        'notary_day':            '______',
        'notary_month':          '____________________',
    }
    out = generate_quit_claim_deed(sample, '/tmp/QuitClaimDeed_Test.pdf')
    print(f'Generated: {out}')
