"""
30-Day Notice to Vacate
========================
Ohio compliant. NCH branded. One page.

FORM FIELDS:
  tenant_name       str    tenant/purchaser full name(s)
  property_address  str    full property address
  notice_date       str    defaults to today
  vacate_by_date    str    defaults to today+30
  reason            str    reason for notice (dropdown)
  reason_detail     str    optional additional detail
  landlord_name     str    defaults to Nice City Homes LLC
  landlord_phone    str    static 330-495-8192
"""

import os
from datetime import date, timedelta
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.colors import HexColor
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, HRFlowable, Table, TableStyle
)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.platypus import Image as RLImage

NCH_RED = HexColor("#8B0000")
DARK    = HexColor("#1A1A1A")
MUTED   = HexColor("#555555")
LGRAY   = HexColor("#F5F5F5")


def _footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica', 9)
    canvas.setFillColor(MUTED)
    canvas.drawCentredString(letter[0] / 2, 0.45 * inch,
        'Nice City Homes LLC  \u00b7  330-495-8192  \u00b7  Canton, Ohio')
    canvas.setStrokeColor(NCH_RED)
    canvas.setLineWidth(0.5)
    canvas.line(inch, 0.6 * inch, letter[0] - inch, 0.6 * inch)
    canvas.restoreState()


def generate(data, output_path=None):
    tenant       = data['tenant_name']
    prop_addr    = data['property_address']
    notice_date  = data.get('notice_date', date.today().strftime('%B %d, %Y'))
    vacate_by    = data.get('vacate_by_date',
                            (date.today() + timedelta(days=30)).strftime('%B %d, %Y'))
    reason       = data.get('reason', 'End of contract term')
    reason_det   = data.get('reason_detail', '')
    landlord     = data.get('landlord_name', 'Nice City Homes LLC')
    phone        = data.get('landlord_phone', '330-495-8192')

    if output_path is None:
        safe = tenant.replace(' ', '_').replace('/', '_')
        output_path = f'/tmp/30DayNotice_{safe}.pdf'

    doc = SimpleDocTemplate(output_path, pagesize=letter,
        leftMargin=inch, rightMargin=inch,
        topMargin=0.75 * inch, bottomMargin=0.85 * inch)

    W = letter[0] - 2 * inch

    def mk(name):
        return {
            'title': ParagraphStyle('title', fontName='Helvetica-Bold', fontSize=18,
                                    textColor=NCH_RED, alignment=TA_CENTER, leading=22,
                                    spaceAfter=2, spaceBefore=0),
            'sub':   ParagraphStyle('sub', fontName='Helvetica-Bold', fontSize=11,
                                    textColor=NCH_RED, alignment=TA_CENTER, leading=15,
                                    spaceAfter=0, spaceBefore=0),
            'body':  ParagraphStyle('body', fontName='Helvetica', fontSize=11,
                                    textColor=DARK, leading=15, spaceAfter=0, spaceBefore=0),
            'bold':  ParagraphStyle('bold', fontName='Helvetica-Bold', fontSize=11,
                                    textColor=DARK, leading=15, spaceAfter=0, spaceBefore=0),
            'label': ParagraphStyle('label', fontName='Helvetica-Bold', fontSize=9,
                                    textColor=MUTED, leading=12, spaceAfter=0, spaceBefore=0),
            'warn':  ParagraphStyle('warn', fontName='Helvetica-Bold', fontSize=11,
                                    textColor=NCH_RED, leading=15, spaceAfter=0, spaceBefore=0),
            'sig':   ParagraphStyle('sig', fontName='Helvetica', fontSize=10,
                                    textColor=DARK, leading=13, spaceAfter=0, spaceBefore=0),
        }[name]

    def hr(color=NCH_RED, t=1, sp=6):
        return HRFlowable(width='100%', thickness=t, color=color,
                          spaceAfter=sp, spaceBefore=sp)
    def sp(n): return Spacer(1, n)

    story = []

    logo_path = os.path.abspath(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'NCH_LOGO.png'))
    logo_h = 0.7 * inch
    logo_w = logo_h * (713 / 338)

    title_block = [
        Paragraph('30-DAY NOTICE TO VACATE', mk('title')),
        Paragraph('Notice to Terminate Occupancy', mk('sub')),
    ]
    if os.path.exists(logo_path):
        hdr = Table([[RLImage(logo_path, width=logo_w, height=logo_h), title_block]],
                    colWidths=[logo_w + 0.15 * inch, W - logo_w - 0.15 * inch])
    else:
        hdr = Table([['', title_block]], colWidths=[0.1 * inch, W - 0.1 * inch])
    hdr.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
    ]))
    story += [hdr, hr(t=1.5, sp=8)]

    story.append(Table([
        [Paragraph('Date:', mk('label')),     Paragraph(str(notice_date), mk('body'))],
        [Paragraph('To:', mk('label')),       Paragraph(f'<b>{tenant}</b>', mk('body'))],
        [Paragraph('Property:', mk('label')), Paragraph(f'<b>{prop_addr}</b>', mk('body'))],
    ], colWidths=[0.85 * inch, W - 0.85 * inch],
    style=TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
    ])))
    story += [hr(color=HexColor('#CCCCCC'), t=0.5, sp=8)]

    story.append(Paragraph(
        f'This notice is provided to <b>{tenant}</b> and all occupants of the premises '
        f'located at <b>{prop_addr}</b>.',
        mk('body')))
    story.append(sp(10))

    story.append(Paragraph(
        f'You are hereby notified that your occupancy of the above premises is '
        f'terminated. You are required to vacate and surrender possession of the '
        f'premises on or before <b>{vacate_by}</b>.',
        mk('body')))
    story.append(sp(10))

    # Reason box
    reason_rows = [
        [Paragraph('REASON FOR NOTICE', mk('label'))],
        [Paragraph(reason, mk('bold'))],
    ]
    if reason_det:
        reason_rows.append([Paragraph(reason_det, mk('body'))])
    rt = Table(reason_rows, colWidths=[W])
    rt.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), LGRAY),
        ('BACKGROUND', (0, 1), (-1, -1), HexColor('#FFFAF0')),
        ('BOX', (0, 0), (-1, -1), 0.5, HexColor('#CCCCCC')),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story += [rt, sp(10)]

    story.append(Paragraph(
        'You are expected to leave the premises in clean condition, remove all personal '
        'property, and return all keys on or before the vacate date above. '
        'Failure to vacate by the required date may result in legal action.',
        mk('body')))
    story.append(sp(10))

    story += [
        hr(color=NCH_RED, t=0.5, sp=5),
        Paragraph(
            f'YOU MUST VACATE THE PREMISES BY: {vacate_by.upper()}',
            mk('warn')),
        hr(color=NCH_RED, t=0.5, sp=10),
    ]

    sig = Table([[
        [Paragraph('Landlord / Agent Signature:', mk('label')), sp(18),
         Paragraph('_' * 36, mk('sig')), sp(4),
         Paragraph(f'{landlord}  |  {phone}', mk('label'))],
        [Paragraph('Date:', mk('label')), sp(18),
         Paragraph('_' * 22, mk('sig'))],
    ]], colWidths=[W * 0.65, W * 0.35])
    sig.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
    ]))
    story.append(sig)

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return output_path


if __name__ == '__main__':
    sample = {
        'tenant_name':     'John A. Smith',
        'property_address':'1117 Arlington Ave SW, Canton OH 44706',
        'notice_date':     'April 7, 2026',
        'vacate_by_date':  'May 7, 2026',
        'reason':          'End of contract term',
        'reason_detail':   '',
        'landlord_name':   'Nice City Homes LLC',
        'landlord_phone':  '330-495-8192',
    }
    out = generate(sample, '/home/claude/30DayNotice_Test.pdf')
    print(f'Generated: {out}')
