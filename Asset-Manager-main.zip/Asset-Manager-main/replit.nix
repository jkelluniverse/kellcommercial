{pkgs}: {
  deps = [
    pkgs.libreoffice
  ];
}
